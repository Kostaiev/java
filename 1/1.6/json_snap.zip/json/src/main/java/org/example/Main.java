package org.example;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Properties;

/**
 * The class, depending on the arguments “json”  or “xml” passed,
 * saves the file of the selected format in the folder "target/".
 * If the format parameter is not passed, json will be the default.
 * Example file:
 * { “message”: “Hello <text from external properties file, username=your name> !"}
 */
public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {

        logger.info("Start program------------------------------>");

        String configPath = "message.properties";

        //use export CONFIG_TEST=exampleValue to set value in console for one session
        if (args.length > 0) {
            configPath = args[0];
        } else if (System.getenv("CONFIG_TEST") != null) {
            configPath = System.getenv("CONFIG_TEST");
        }

        File file = new File(configPath);
        try (InputStream input = file.exists() ? new FileInputStream(file) : Main.class.getClassLoader().getResourceAsStream(configPath)) {
            Properties configProperties = new Properties();
            configProperties.load( new InputStreamReader(input, StandardCharsets.UTF_8));
           
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        String username = getProperty("username");
        logger.info("set username: " + username);

        String format = System.getProperty("format", "xml").toLowerCase();
        logger.info("set file format: " + format);

        Message message = new Message("Hello " + username + "!");
        logger.info("new Message object: " + message);

        switch (format) {
            case "json": {
                printJson(message);
                logger.info("switch json parameter");
                break;
            }
            case "xml": {
                printXml(message);
                logger.info("switch xml parameter");
                break;
            }
            default: {
                printJson(message);
                logger.info("switch default parameter");
            }
        }
        logger.info("<------------------------------End program");
    }

    /**
     * Finds the .properties file and sets the requested parameter.
     *
     * @param name parameter name
     * @return parameter value
     */
    private static String getProperty(String name) {
        Properties appProps = new Properties();
                                                                                                                // "xmlMessage.xml"
        try (InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("message.properties");
             InputStreamReader reader = new InputStreamReader(inputStream, StandardCharsets.UTF_8)) {
             appProps.load(reader);
//            appProps.loadFromXML(inputStream);
            System.out.println( appProps.getProperty(name));
        } catch (IOException e) {
            logger.error("getProperty Exception");
            e.printStackTrace();
        }
        logger.info("Property " + name + " is find");
        return appProps.getProperty(name);
    }

    /**
     * Saves the created object in json format
     *
     * @param obj a class object to write to a file
     */
    private static void printJson(Message obj) {
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            String json = objectMapper.writeValueAsString(obj);
            System.out.println(json);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        logger.info("Json file is saved");
    }

    /**
     * Saves the created object in xml format
     *
     * @param obj a class object to write to a file
     */
    private static void printXml(Message obj) {
        XmlMapper xmlMapper = new XmlMapper();
        try {
            String xml = xmlMapper.writeValueAsString(obj);
            System.out.println(xml);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        logger.info("Xml file is saved");
    }
}